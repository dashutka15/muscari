<?php
declare(strict_types=1);

require dirname(__DIR__) . '/auth.php';
require dirname(__DIR__) . '/validation.php';
require dirname(__DIR__) . '/catalog.php';
require dirname(__DIR__) . '/actions.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function respond(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $route = is_string($_GET['route'] ?? null) ? $_GET['route'] : '';
    $origin = (useHttps() ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '');
    if ($method !== 'GET' && ($_SERVER['HTTP_ORIGIN'] ?? '') !== $origin) {
        inputError('Источник запроса не разрешён.', 403);
    }

    $user = signedInUser();
    if ($method !== 'GET' && $user) {
        try {
            checkCsrf($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);
        } catch (RuntimeException $error) {
            inputError($error->getMessage(), 403);
        }
    }
    if ($route === 'session' && $method === 'GET') {
        respond(['user' => $user, 'csrf' => csrfToken()]);
    }
    if (str_starts_with($route, 'admin/')) {
        $isAdmin = $user && $user['role'] === 'admin';
        session_write_close();
        if (!$isAdmin) {
            inputError('Сначала войдите в админ-панель.', 401);
        }
    }

    $db = database($config);
    if ($route === 'catalog' && $method === 'GET') {
        $reviews = query($db, "SELECT id, name, text, rating, source FROM reviews WHERE status = 'published' ORDER BY created_at DESC, id LIMIT 100")->fetchAll();
        respond(catalog($db) + ['reviews' => $reviews]);
    }
    if ($route === 'bookings' && $method === 'POST') {
        respond(['id' => addBooking($db, input(), ($user['role'] ?? '') === 'client' ? $user['id'] : null)], 201);
    }
    if ($route === 'reviews' && $method === 'POST') {
        respond(['id' => addReview($db, input(), ($user['role'] ?? '') === 'client' ? $user['id'] : null)], 201);
    }
    if ($route === 'admin/state' && $method === 'GET') {
        $bookings = query($db, 'SELECT *, created_at AS created FROM bookings ORDER BY created_at DESC, id')->fetchAll();
        $reviews = query($db, 'SELECT *, created_at AS created FROM reviews ORDER BY created_at DESC, id')->fetchAll();
        respond(catalog($db) + ['bookings' => $bookings, 'reviews' => $reviews]);
    }
    if (!preg_match('~\Aadmin/(services|offers|team|bookings|reviews)(?:/([a-z0-9-]{1,64}))?\z~', $route, $match)) {
        inputError('Страница не найдена.', 404);
    }
    $table = $match[1];
    $id = $match[2] ?? null;

    if (isset(CATALOG_FIELDS[$table])) {
        if (($method === 'POST' && $id === null) || ($method === 'PUT' && $id !== null)) {
            respond(['id' => saveCatalog($db, $table, input(), $id)]);
        }
        if ($method === 'DELETE' && $id !== null) {
            if (!query($db, "DELETE FROM $table WHERE id = ?", [$id])->rowCount()) {
                inputError('Запись не найдена.', 404);
            }
            respond(['ok' => true]);
        }
    } elseif ($method === 'PATCH' && $id !== null) {
        $status = validateChoice(input(), 'status', $table === 'bookings' ? BOOKING_STATUSES : REVIEW_STATUSES, 'Статус');
        if (!updateRecord($db, $table, $id, ['status' => $status])) {
            inputError('Запись не найдена.', 404);
        }
        respond(['ok' => true]);
    }
    inputError('Метод не поддерживается.', 405);
} catch (ApiError $error) {
    respond(['error' => $error->getMessage()], $error->getCode());
} catch (PDOException $error) {
    if (($error->errorInfo[1] ?? 0) === 1451) {
        respond(['error' => 'Сначала измените или удалите акцию, связанную с этой услугой.'], 409);
    }
    if (($error->errorInfo[1] ?? 0) === 1452) {
        respond(['error' => 'Связанная услуга больше недоступна. Обновите каталог.'], 409);
    }
    error_log($error->getMessage());
    respond(['error' => 'Ошибка базы данных. Проверьте настройки config.php и импорт database.sql или upgrade-accounts.sql.'], 503);
} catch (Throwable $error) {
    error_log($error->getMessage());
    respond(['error' => 'Не удалось выполнить запрос. Проверьте, что PHP и pdo_mysql включены.'], 500);
}
